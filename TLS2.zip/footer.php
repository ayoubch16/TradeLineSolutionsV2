<div class="footer">
<div class="col text-center footer2 py-5">
<h4>Nous attendons votre appel sur :</h4>
<h1><img style="filter:brightness(0) invert(1)" src="image/icones/phone-call(1).png"> 05 30 06 50 24</h1>
<h4>Nous sommes ouverts</h4>
<p style="margin-bottom:0!important">Du Lundi au Vendredi : 9h00 -> 17h00 &emsp; et le &emsp; Samedi :
9h00 ->14h00</p>
</div>
<div class="footer1">
<div class="row align-items-start">
<div class="footer-col-1 text-center m-3">
<h3 class="title_footer text-center mb-5">Trouvez-Nous </h3>
<div style="width:100%">
<iframe scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=220px&amp;height=220px&amp;hl=en&amp;q=8%20%D8%B4%D8%A7%D8%B1%D8%B9%20%D9%85%D8%AD%D9%85%D8%AF%20%D8%A7%D9%84%D8%AE%D8%A7%D9%85%D8%B3%D8%8C%20%D8%B3%D9%84%D8%A7+(Trade%20Line%20Solutions)&amp;t=&amp;z=16&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="220px" height="220px" frameborder="0">
<a href="https://www.gps.ie/sport-gps/">fitness tracker</a>
</iframe>
</div>
</div>
<div class="footer-col-1 text-center m-3">
<img src="image/logoW.png" style="width:220px" />
<p class="p-3" style="font-size:15px">Que vous soyez particulier, professionnel ou personne
morale, Nous vous proposons un accompagnement à l’achat, la vente, la gestion locative, et le
conseil bancaire et technique immobilier (financement bancaire, construction, ...)</p>
</div>
<div class="footer-col-1 m-3">
<h3 class="title_footer text-center mb-5">Suivez-Nous</h3>
<ul class="text-start p-3" style="font-size:15px">
<li><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/location.png"> Av Mohamed V,Res 1,202-203, 1er Etage N'1,Hay
Karima,Tabriket-Sale</li>
<li><a class="my-1" style="text-decoration:none;color:white" href="https://web.facebook.com/TLS-IMMO-111322111153327/?_rdc=1&_rdr"><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/facebook.png"> Facebook</a> </li>
<li><a style="text-decoration:none;color:white" href="https://www.instagram.com/tls.immo?fbclid=IwAR14cEQjlgIz19kZ2yzs2M0x_mCvr8hs8Y5yFlZeEoDkfjgyOy9Gaq8XliQ"><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/instagram.png"> Instagram</a> </li>
<li><a class="my-1" style="text-decoration:none;color:white" href="tel:+212530065024"><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/phone-call.png"> 05 30 06 50 24 </a> </li>
<li><a style="text-decoration:none;color:white" href="https://www.linkedin.com/company/trade-line-solutions"><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/linkedin.png"> LinkdeIn</a> </li>
</ul>
</div>
</div>
<p class="copyright" style="font-size:15px"><img class="mr-2" style="filter:brightness(0) invert(1);width:20px;margin-bottom:0" src="image/icones/copyright-regular.svg"> 2021 All Rights Reserved. powered By <a target="blanck" style="color:#fff!important" href="https://www.linkedin.com/in/ayoub-choukri-b43997160/">TRADE LINE SOULTIONS</a> .
</p>
</div>